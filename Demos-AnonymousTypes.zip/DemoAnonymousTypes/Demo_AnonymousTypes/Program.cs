﻿using System;
using System.IO;

namespace Demo_AnonymousTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            string pathOfExe = System.Reflection.Assembly.GetEntryAssembly().Location;
            FileInfo fileInfo = new FileInfo(pathOfExe);
            var simpleFileInfo = new
            {
                Filename = fileInfo.Name,
                FileSize = fileInfo.Length
            };
            Console.WriteLine("File name: " + simpleFileInfo.Filename + ". Size: " + simpleFileInfo.FileSize + " bytes");
           
        }
    }
}
