﻿using System;

namespace DemoBuiltInDelegates
{

    class Program
    {
         static void MyIntMethod(int i)
         {
                Console.WriteLine($"MyIntMethod param {i}");
         }
        static void MyStringMethod(int i, string s)
        {
            Console.WriteLine($"MyStringMethod param {i} en param {s}");
        }
        static bool MyClassIsSleeping(DayOfWeek weekday)
        {
            if (DateTime.Now.Hour > 12 && weekday != DayOfWeek.Saturday)
                return true;
            else
                return false;
        }
         static void Main(string[] args)
        {
            //Using built-in generic delegate Action<>
            Action<int> myIntAct = MyIntMethod;
            Action<int, string> myIntStringAct = MyStringMethod;
            myIntAct(10);
            myIntStringAct(5, "Hello");
            //built-in generic delegate Func<> bv zonder param en met return waarde
            Func<DayOfWeek,bool> mySleepingFunc = MyClassIsSleeping;
            Console.WriteLine("Sleeping on Saturday = " + mySleepingFunc(DayOfWeek.Saturday));
            Predicate<DayOfWeek> mySleepingPredicate = MyClassIsSleeping;
            Console.WriteLine("Sleeping today = " + mySleepingPredicate(DateTime.Now.DayOfWeek));
            Console.Read();

        }
    }
}
