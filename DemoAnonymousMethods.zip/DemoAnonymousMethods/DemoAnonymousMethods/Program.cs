﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoAnonymousMethods
{
    class Program
    {
        delegate void SomeDelegate(string str);
        static void Main()
        {
            SomeDelegate d = delegate(string str)
            {
                Console.WriteLine(str);
            };
            d("Hello");
            //Lambda expression zonder terugkeerwaarde
            Action act = () =>
            {
                Console.WriteLine("Inside Lambda expression");
            };
            act();
            Action<string> act2 = (s) => Console.WriteLine(s);
            act2("Hello World");
            Console.Read();
        }
  }
}
