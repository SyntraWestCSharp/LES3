﻿using System;

namespace DemoSealedClass
{
    public sealed class Animal
    { 
        public String Kind { get; set; }
        public int Speed { get; set; }
    }
    //public class Dog : Animal { }
    //Afgeleide class van sealed class niet mogelijk



    public static class Extensions
    {
        public static void IncreaseSpeed(this Animal animal)
        {
            animal.Speed++;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Animal a = new Animal { Kind = "Leopard", Speed=80};
            a.IncreaseSpeed();

            Console.WriteLine($"Animal: {a.Kind} Speed:{a.Speed}");
        }
    }
}
