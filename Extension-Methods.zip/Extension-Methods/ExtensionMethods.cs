﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

public static class Extensions
{

    public static void IncreaseWidth(this IList<int> list, int amount)
    {
        for (int i = 0; i < list.Count; i++)
        {
            list[i] += amount;
        }
    }
    public static int WordCount(this string str)
    {
        return str.Split(new char[] { ' ', '.', '?' },
            StringSplitOptions.RemoveEmptyEntries).Length;
    }
    public static string ExtMethod<T>(this IEnumerable<T> enumeration)
    {
        StringBuilder result = new StringBuilder();
        result.Append("[ ");
        foreach (var item in enumeration)
        {
            result.Append(item.ToString());
            result.Append(" ");
        }
        result.Append("]");
        return result.ToString();
    }
}
class ExtensionMethods
{
    static void Main() {
        string s = "Hello Extension Methods";
        int i = s.WordCount();
        Console.WriteLine(i);

        ObservableCollection<int> ints = new ObservableCollection<int> { 1, 2, 3, 4, 5 };
        Console.WriteLine(ints.ToString());
        Console.WriteLine(ints.ExtMethod<int>());

        //ints.IncreaseWidth(5);
        //Console.WriteLine(ints.ExtMethod<int>());
    }
}
