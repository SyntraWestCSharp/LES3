﻿using System;

namespace Oefening2_GenericDelegate
{
    /*Declareer een generic delegate die een referentie kan bijhouden 
     * naar deze methods:
     * 	public static bool IsGelijk(int getal1,int getal2)
	    public static bool IsGelijk(double getal1, double getal2)
	    public static bool IsGelijk<T>(T param1, T param2)
    */
    class MyMethodsClass
    {
        public static bool IsGelijk(int getal1, int getal2)
        {
            return getal1 == getal2;
        }
        public static bool IsGelijk(double getal1, double getal2)
        {
            return getal1 == getal2;
        }
        public static bool IsGelijk<T>(T param1, T param2)
        {
            return param1.Equals(param2);
        }
    }
    class Program
    {
        private delegate bool MyGenericDelegate<T>(T item1, T item2);
        static void Main(string[] args)
        {
            MyGenericDelegate<int> del_gelijkeInts = new MyGenericDelegate<int>(MyMethodsClass.IsGelijk);
            Console.WriteLine(del_gelijkeInts(3, 3)); //Geeft true
            MyGenericDelegate<double> del_gelijkeDbls= new MyGenericDelegate<double>(MyMethodsClass.IsGelijk);
            Console.WriteLine(del_gelijkeDbls(2.5, 2.9));//Geeft false
            MyGenericDelegate<string> del_gelijkestr = new MyGenericDelegate<string>(MyMethodsClass.IsGelijk<string>);
            Console.WriteLine(del_gelijkestr("hello", "hello"));//geeft true
            //var kan je niet doorgeven, in noodgevallen kan je dynamic type gebruiken (op eigen risico, geen typeSafety!)
            MyGenericDelegate<dynamic> del_gelijkeAnonymous = new MyGenericDelegate<dynamic>(MyMethodsClass.IsGelijk<dynamic>);
            var anonObj1 = new { Naam = "Joske", Leeftijd = 19 };
            var anonObj2 = new { Naam = "Joske", Leeftijd = 19 };
            Console.WriteLine(del_gelijkeAnonymous(anonObj1, anonObj2));
        }
    }
}
